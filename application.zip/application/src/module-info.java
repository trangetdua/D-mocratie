/**
 * 
 */
/**
 * 
 */
module application {
	requires java.desktop;
	requires java.sql;
	requires org.json;
	requires java.net.http;
	//requires org.json;
}